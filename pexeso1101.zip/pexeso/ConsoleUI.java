package pexeso;

import java.util.Scanner;

public class ConsoleUI {
	private Field field = new Field(4);
	private Scanner scanner = new Scanner(System.in);

	public int run() {
		long startTime = System.currentTimeMillis();
		print();
		while (field.getState() != GameState.SOLVED) {
			processInput();
			print();
		}
		return 3;
	}

	private void processInput() {
		System.out.println("Enter tile coordinates to open tile: ");
		String input = scanner.nextLine().trim().toUpperCase();
		if("X".equals(input))
			System.exit(0);
		
		/*************************************************************/
	}

	private void print() {
		for (int row = 0; row < field.getRowCount(); row++) {
			for (int column = 0; column < field.getRowCount(); column++) {
				if (field.getTile(row, column).getState() != TileState.CLOSED) {
					System.out.print(field.getTile(row, column).getValue());
				} else {
					System.out.print("X");
				}
			}

			System.out.println();
		}
	}

	public String getName() {
		return "Pexeso";
	}

}
