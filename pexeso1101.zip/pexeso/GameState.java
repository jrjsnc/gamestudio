package pexeso;

public enum GameState {
	PLAYING,SOLVED
}
