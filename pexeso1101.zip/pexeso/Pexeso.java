package pexeso;

public class Pexeso {

	public static void main(String[] args) {
		ConsoleUI c = new ConsoleUI();
		c.run();
	}
}
