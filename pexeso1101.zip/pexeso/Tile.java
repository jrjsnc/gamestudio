package pexeso;

public class Tile {
	private TileState state;
	private int value;
	
	public Tile() {
		state = TileState.OPENED;
	}
	
	public int getValue() {
		return value;
	}
	
	public void setValue(int value) {
		this.value = value;
	}
	
	public TileState getState() {
		return state;
	}
	
	public void setState(TileState state) {
		this.state = state;
	}
}
