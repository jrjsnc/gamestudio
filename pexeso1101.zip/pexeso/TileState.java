package pexeso;

public enum TileState {
	OPENED, CLOSED, PAIRED
}
